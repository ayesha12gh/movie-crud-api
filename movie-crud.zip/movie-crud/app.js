// app.js
const express = require("express");
const app = express();
const PORT = 3000;

// allow JSON bodies (for POST/PUT requests)
app.use(express.json());

// temporary data
let movies = [
  { id: 1, title: "Inception", director: "Christopher Nolan", year: 2010 },
  { id: 2, title: "The Matrix", director: "The Wachowskis", year: 1999 },
  { id: 3, title: "Parasite", director: "Bong Joon-ho", year: 2019 }
];

// helper function to get next ID
const getNextId = () =>
  movies.length ? Math.max(...movies.map(m => m.id)) + 1 : 1;

// 🏠 DEFAULT ROUTE — show all movies as HTML list
app.get("/", (req, res) => {
  const list = movies
    .map(m => `<li><strong>${m.title}</strong> — ${m.director} (${m.year})</li>`)
    .join("");
  const html = `
    <html>
      <head><title>Movies</title></head>
      <body>
        <h1>Movie Collection</h1>
        <ul>${list}</ul>
      </body>
    </html>`;
  res.send(html);
});

// 🎬 GET /movies — return all movies as JSON
app.get("/movies", (req, res) => {
  res.json(movies);
});

// 🎞 GET /movies/:id — return one movie by ID
app.get("/movies/:id", (req, res) => {
  const id = Number(req.params.id);
  const movie = movies.find(m => m.id === id);

  if (!movie) {
    return res.status(404).json({ error: "Movie not found" });
  }

  res.json(movie);
});

// ➕ POST /movies — add a new movie
app.post("/movies", (req, res) => {
  const { title, director, year } = req.body;

  if (!title || !director || !year) {
    return res.status(400).json({ error: "title, director and year are required" });
  }

  const newMovie = { id: getNextId(), title, director, year: Number(year) };
  movies.push(newMovie);

  res.status(201).json(newMovie);
});

// ✏️ PUT /movies/:id — update an existing movie
app.put("/movies/:id", (req, res) => {
  const id = Number(req.params.id);
  const { title, director, year } = req.body;
  const movie = movies.find(m => m.id === id);

  if (!movie) {
    return res.status(404).json({ error: "Movie not found" });
  }

  if (title) movie.title = title;
  if (director) movie.director = director;
  if (year) movie.year = Number(year);

  res.json(movie);
});

// ❌ DELETE /movies/:id — remove a movie
app.delete("/movies/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = movies.findIndex(m => m.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Movie not found" });
  }

  const deleted = movies.splice(index, 1);
  res.json({ message: "Movie deleted", deleted });
});

// 🚀 start the server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
